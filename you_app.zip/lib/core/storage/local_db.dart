import 'package:hive_flutter/hive_flutter.dart';

/// Local storage (Hive). Everything is saved as JSON text, so no generated
/// adapters are needed. Data stays on the phone and works fully offline.
class LocalDb {
  LocalDb._();

  static const String studyBoxName = 'you_study_v2';
  static const String goalBoxName = 'you_goals_v2';
  static const String settingsBoxName = 'you_settings_v2';

  static late Box<String> studyBox;
  static late Box<String> goalBox;
  static late Box<String> settingsBox;

  static Future<void> init() async {
    await Hive.initFlutter();
    studyBox = await Hive.openBox<String>(studyBoxName);
    goalBox = await Hive.openBox<String>(goalBoxName);
    settingsBox = await Hive.openBox<String>(settingsBoxName);
  }

  static Future<void> clearAll() async {
    await studyBox.clear();
    await goalBox.clear();
    await settingsBox.clear();
  }
}
