class AppConstants {
  AppConstants._();

  static const String appName = 'YOU';
  static const String appVersion = '1.1.0';

  /// A day with at least this many minutes is shown as a "heavy study" day.
  static const int heavyStudyMinutes = 120;

  static const int defaultDailyTargetMinutes = 60;
  static const List<int> dailyTargetOptions = [30, 60, 90, 120, 180, 240];
}
