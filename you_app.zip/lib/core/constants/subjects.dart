import 'package:flutter/widgets.dart';

import '../localization/app_strings.dart';

class Subjects {
  Subjects._();

  /// Stable ids saved in the database (always English).
  static const List<String> defaults = [
    'Bangla',
    'English',
    'Mathematics',
    'General Science',
    'Bangladesh Affairs',
    'International Affairs',
    'ICT',
    'Geography',
    'Environment',
    'Mental Ability',
    'Ethics, Values & Good Governance',
    'Current Affairs',
    'Other',
  ];

  static const Map<String, String> icons = {
    'Bangla': '📖',
    'English': '🔤',
    'Mathematics': '📐',
    'General Science': '🔬',
    'Bangladesh Affairs': '🇧🇩',
    'International Affairs': '🌍',
    'ICT': '💻',
    'Geography': '🗺️',
    'Environment': '🌿',
    'Mental Ability': '🧠',
    'Ethics, Values & Good Governance': '⚖️',
    'Current Affairs': '📰',
    'Other': '📚',
  };

  static String icon(String id) => icons[id] ?? '📚';

  /// Localised label. Custom subjects are shown exactly as typed.
  static String label(BuildContext context, String id) {
    final strings = AppStrings.of(context);
    final key = 'subj_$id';
    return strings.has(key) ? strings.t(key) : id;
  }

  static List<String> withCustom(List<String> custom) =>
      [...defaults, ...custom.where((c) => !defaults.contains(c))];
}
