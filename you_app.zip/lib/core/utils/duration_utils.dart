import 'package:flutter/widgets.dart';

import '../localization/app_strings.dart';

class AppDurationUtils {
  AppDurationUtils._();

  static String formatMinutes(BuildContext context, int minutes) {
    final h = context.tr('unitH');
    final m = context.tr('unitM');
    if (minutes <= 0) return '0$m';
    if (minutes < 60) return '$minutes$m';
    final hh = minutes ~/ 60;
    final mm = minutes % 60;
    return mm == 0 ? '$hh$h' : '$hh$h $mm$m';
  }

  static String formatHours(BuildContext context, int minutes) {
    final h = context.tr('unitH');
    if (minutes <= 0) return '0$h';
    final hours = minutes / 60;
    if (hours >= 10) return '${hours.toStringAsFixed(0)}$h';
    return '${hours.toStringAsFixed(1)}$h';
  }
}
