import 'package:intl/intl.dart';

class AppDateUtils {
  AppDateUtils._();

  static DateTime startOfDay(DateTime d) => DateTime(d.year, d.month, d.day);

  static bool isSameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;

  static String formatShort(DateTime d, String locale) =>
      DateFormat('d MMM y', locale).format(d);

  static String formatFull(DateTime d, String locale) =>
      DateFormat('EEEE, d MMMM y', locale).format(d);

  static String formatMonthYear(DateTime d, String locale) =>
      DateFormat('MMMM y', locale).format(d);

  static int daysInMonth(int year, int month) =>
      DateTime(year, month + 1, 0).day;

  /// Calendar weeks start on Saturday (Bangladesh). Index 0 = Saturday.
  static String weekdayShort(int index, String locale) =>
      DateFormat('E', locale).format(DateTime(2024, 1, 6 + index));

  /// Empty cells before the 1st of the month in a Saturday-first grid.
  static int leadingBlanks(DateTime firstOfMonth) =>
      (firstOfMonth.weekday + 1) % 7;
}
