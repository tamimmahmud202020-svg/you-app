import 'package:flutter/material.dart';

class BarItem {
  const BarItem({
    required this.label,
    required this.value,
    required this.valueText,
    this.highlight = false,
  });

  final String label;
  final int value;
  final String valueText;
  final bool highlight;
}

/// Very small bar chart (no packages). Works offline, light on memory.
class SimpleBarChart extends StatelessWidget {
  const SimpleBarChart({super.key, required this.items, this.barHeight = 130});

  final List<BarItem> items;
  final double barHeight;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    var maxValue = 0;
    for (final i in items) {
      if (i.value > maxValue) maxValue = i.value;
    }

    return SizedBox(
      height: barHeight + 60,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          for (final item in items)
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 3),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SizedBox(
                      height: 18,
                      child: FittedBox(
                        fit: BoxFit.scaleDown,
                        child: Text(
                          item.valueText,
                          style: theme.textTheme.labelSmall
                              ?.copyWith(color: scheme.onSurfaceVariant),
                        ),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Container(
                      height: (maxValue == 0 || item.value == 0)
                          ? 3
                          : (item.value / maxValue * barHeight)
                              .clamp(3.0, barHeight)
                              .toDouble(),
                      decoration: BoxDecoration(
                        color: item.value == 0
                            ? scheme.outlineVariant
                            : item.highlight
                                ? scheme.tertiary
                                : scheme.primary,
                        borderRadius: BorderRadius.circular(6),
                      ),
                    ),
                    const SizedBox(height: 6),
                    SizedBox(
                      height: 18,
                      child: FittedBox(
                        fit: BoxFit.scaleDown,
                        child: Text(
                          item.label,
                          style: theme.textTheme.labelSmall?.copyWith(
                            fontWeight: item.highlight
                                ? FontWeight.w800
                                : FontWeight.w500,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
