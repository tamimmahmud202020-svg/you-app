import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../../core/constants/subjects.dart';
import '../../core/localization/app_strings.dart';
import '../../core/utils/date_utils.dart';
import '../../core/utils/duration_utils.dart';
import '../../core/widgets/bar_chart.dart';
import '../../core/widgets/common_widgets.dart';
import '../goals/goal_provider.dart';
import '../goals/goals_screen.dart';
import '../goals/monthly_goal_card.dart';
import '../profile/settings_provider.dart';
import '../revision/revision_view.dart';
import '../study/study_provider.dart';
import 'progress_stats.dart';

class ProgressScreen extends StatelessWidget {
  const ProgressScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text(context.tr('navProgress')),
          bottom: TabBar(
            tabs: [
              Tab(text: context.tr('overview')),
              Tab(text: context.tr('revision')),
            ],
          ),
        ),
        body: const TabBarView(
          children: [
            _OverviewTab(),
            RevisionView(),
          ],
        ),
      ),
    );
  }
}

class _OverviewTab extends StatelessWidget {
  const _OverviewTab();

  String _hours(BuildContext context, int minutes) =>
      minutes <= 0 ? '' : AppDurationUtils.formatHours(context, minutes);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final study = context.watch<StudyProvider>();
    final goal = context.watch<GoalProvider>();
    final locale = context.watch<SettingsProvider>().languageCode;

    if (study.isEmpty) {
      return EmptyState(
        icon: Icons.insights_outlined,
        title: context.tr('noDataYet'),
        subtitle: context.tr('noDataYetHint'),
      );
    }

    final now = DateTime.now();
    final stats = ProgressStats.from(study.allRecords, now);

    final weekItems = [
      for (final d in stats.last7Days)
        BarItem(
          label: DateFormat('E', locale).format(d.date),
          value: d.minutes,
          valueText: _hours(context, d.minutes),
          highlight: AppDateUtils.isSameDay(d.date, now),
        ),
    ];
    final monthItems = [
      for (final m in stats.last6Months)
        BarItem(
          label: DateFormat('MMM', locale).format(m.month),
          value: m.minutes,
          valueText: _hours(context, m.minutes),
          highlight: m.month.year == now.year && m.month.month == now.month,
        ),
    ];

    final maxSubject =
        stats.bySubject.isEmpty ? 1 : stats.bySubject.first.minutes;

    return LayoutBuilder(
      builder: (context, constraints) {
        final cardWidth = (constraints.maxWidth - 32 - 10) / 2;
        Widget stat(String label, String value, IconData icon, [Color? c]) {
          return SizedBox(
            width: cardWidth,
            child: StatCard(label: label, value: value, icon: icon, color: c),
          );
        }

        return ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
          children: [
            MonthlyGoalCard(
              monthMinutes: study.monthMinutes,
              goalHours: goal.targetHours,
              onTap: () {
                Navigator.of(context).push(
                  MaterialPageRoute<void>(builder: (_) => const GoalsScreen()),
                );
              },
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                stat(
                  context.tr('totalStudyTime'),
                  AppDurationUtils.formatMinutes(context, stats.totalMinutes),
                  Icons.schedule,
                ),
                stat(
                  context.tr('studyDaysLbl'),
                  '${stats.studyDays}',
                  Icons.event_available,
                  scheme.tertiary,
                ),
                stat(
                  context.tr('currentStreak'),
                  context.tr('daysCount', {'n': '${study.currentStreak}'}),
                  Icons.local_fire_department,
                  Colors.orange,
                ),
                stat(
                  context.tr('longestStreak'),
                  context.tr('daysCount', {'n': '${study.longestStreak}'}),
                  Icons.emoji_events_outlined,
                ),
                stat(
                  context.tr('topicsLbl'),
                  '${stats.topics}',
                  Icons.topic_outlined,
                  scheme.tertiary,
                ),
                stat(
                  context.tr('sessionsLbl'),
                  '${stats.sessions}',
                  Icons.menu_book_outlined,
                ),
              ],
            ),
            SectionHeader(context.tr('weeklyChart')),
            AppCard(
              padding: const EdgeInsets.fromLTRB(12, 16, 12, 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 4, bottom: 12),
                    child: Text(
                      '${context.tr('thisWeekTotal')}: '
                      '${AppDurationUtils.formatMinutes(context, stats.weekMinutes)}',
                      style: theme.textTheme.bodyMedium
                          ?.copyWith(fontWeight: FontWeight.w600),
                    ),
                  ),
                  SimpleBarChart(items: weekItems),
                ],
              ),
            ),
            SectionHeader(context.tr('monthlyChart')),
            AppCard(
              padding: const EdgeInsets.fromLTRB(12, 16, 12, 12),
              child: SimpleBarChart(items: monthItems),
            ),
            SectionHeader(context.tr('subjectWise')),
            AppCard(
              padding: const EdgeInsets.all(14),
              child: Column(
                children: [
                  for (final s in stats.bySubject)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 6),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  '${Subjects.icon(s.subject)} '
                                  '${Subjects.label(context, s.subject)}',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: theme.textTheme.bodyMedium,
                                ),
                              ),
                              const SizedBox(width: 8),
                              Text(
                                AppDurationUtils.formatMinutes(
                                    context, s.minutes),
                                style: theme.textTheme.labelLarge
                                    ?.copyWith(fontWeight: FontWeight.w700),
                              ),
                            ],
                          ),
                          const SizedBox(height: 6),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(6),
                            child: LinearProgressIndicator(
                              value: s.minutes / maxSubject,
                              minHeight: 8,
                              backgroundColor: scheme.surfaceContainerHighest,
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                SizedBox(
                  width: cardWidth,
                  child: _SubjectHighlight(
                    title: context.tr('mostStudied'),
                    icon: Icons.trending_up,
                    item: stats.mostStudied,
                  ),
                ),
                SizedBox(
                  width: cardWidth,
                  child: _SubjectHighlight(
                    title: context.tr('leastStudied'),
                    icon: Icons.trending_down,
                    item: stats.leastStudied,
                  ),
                ),
              ],
            ),
          ],
        );
      },
    );
  }
}

class _SubjectHighlight extends StatelessWidget {
  const _SubjectHighlight({
    required this.title,
    required this.icon,
    required this.item,
  });

  final String title;
  final IconData icon;
  final SubjectTime? item;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    return AppCard(
      padding: const EdgeInsets.all(12),
      child: SizedBox(
        width: double.infinity,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: scheme.primary, size: 22),
            const SizedBox(height: 8),
            Text(
              title,
              style: theme.textTheme.bodySmall
                  ?.copyWith(color: scheme.onSurfaceVariant),
            ),
            const SizedBox(height: 2),
            Text(
              item == null ? '—' : Subjects.label(context, item!.subject),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: theme.textTheme.titleSmall
                  ?.copyWith(fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 2),
            Text(
              item == null
                  ? context.tr('notEnoughData')
                  : AppDurationUtils.formatMinutes(context, item!.minutes),
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
              style: theme.textTheme.bodySmall
                  ?.copyWith(color: scheme.onSurfaceVariant),
            ),
          ],
        ),
      ),
    );
  }
}
