import '../../core/utils/date_utils.dart';
import '../study/study_record.dart';

class SubjectTime {
  const SubjectTime(this.subject, this.minutes);
  final String subject;
  final int minutes;
}

class DayMinutes {
  const DayMinutes(this.date, this.minutes);
  final DateTime date;
  final int minutes;
}

class MonthMinutes {
  const MonthMinutes(this.month, this.minutes);
  final DateTime month; // first day of the month
  final int minutes;
}

/// All numbers on the Progress screen, calculated from saved records.
class ProgressStats {
  const ProgressStats({
    required this.totalMinutes,
    required this.sessions,
    required this.studyDays,
    required this.topics,
    required this.bySubject,
    required this.last7Days,
    required this.last6Months,
  });

  final int totalMinutes;
  final int sessions;
  final int studyDays;
  final int topics;
  final List<SubjectTime> bySubject; // most studied first
  final List<DayMinutes> last7Days; // oldest -> today
  final List<MonthMinutes> last6Months; // oldest -> this month

  SubjectTime? get mostStudied => bySubject.isEmpty ? null : bySubject.first;

  /// Only meaningful when at least 2 subjects were studied.
  SubjectTime? get leastStudied => bySubject.length < 2 ? null : bySubject.last;

  int get weekMinutes => last7Days.fold(0, (s, d) => s + d.minutes);

  factory ProgressStats.from(List<StudyRecord> records, DateTime now) {
    var total = 0;
    final subjectMap = <String, int>{};
    final dayMap = <DateTime, int>{};
    final monthMap = <String, int>{};
    final days = <DateTime>{};
    final topics = <String>{};

    for (final r in records) {
      total += r.durationMinutes;
      subjectMap[r.subject] = (subjectMap[r.subject] ?? 0) + r.durationMinutes;
      final d = AppDateUtils.startOfDay(r.date);
      days.add(d);
      dayMap[d] = (dayMap[d] ?? 0) + r.durationMinutes;
      final mk = '${r.date.year}-${r.date.month}';
      monthMap[mk] = (monthMap[mk] ?? 0) + r.durationMinutes;
      topics.add(r.topicKey);
    }

    final bySubject = subjectMap.entries
        .map((e) => SubjectTime(e.key, e.value))
        .toList()
      ..sort((a, b) => b.minutes.compareTo(a.minutes));

    final last7 = <DayMinutes>[
      for (var i = 6; i >= 0; i--)
        () {
          final date = DateTime(now.year, now.month, now.day - i);
          return DayMinutes(date, dayMap[date] ?? 0);
        }(),
    ];

    final last6 = <MonthMinutes>[
      for (var i = 5; i >= 0; i--)
        () {
          final m = DateTime(now.year, now.month - i, 1);
          return MonthMinutes(m, monthMap['${m.year}-${m.month}'] ?? 0);
        }(),
    ];

    return ProgressStats(
      totalMinutes: total,
      sessions: records.length,
      studyDays: days.length,
      topics: topics.length,
      bySubject: bySubject,
      last7Days: last7,
      last6Months: last6,
    );
  }
}
