class MonthlyGoal {
  const MonthlyGoal({
    required this.year,
    required this.month,
    required this.targetHours,
  });

  final int year;
  final int month;
  final int targetHours;

  /// One goal per month, so the key doubles as the storage id.
  String get key => '$year-${month.toString().padLeft(2, '0')}';

  Map<String, dynamic> toJson() => <String, dynamic>{
        'year': year,
        'month': month,
        'targetHours': targetHours,
      };

  factory MonthlyGoal.fromJson(Map<String, dynamic> json) {
    final year = (json['year'] as num).toInt();
    final month = (json['month'] as num).toInt();
    final hours = (json['targetHours'] as num).toInt();
    if (month < 1 || month > 12 || hours <= 0) {
      throw const FormatException('Invalid goal');
    }
    return MonthlyGoal(year: year, month: month, targetHours: hours);
  }
}
