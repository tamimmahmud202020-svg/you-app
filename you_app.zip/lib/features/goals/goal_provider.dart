import 'dart:convert';

import 'package:flutter/foundation.dart';

import '../../core/storage/local_db.dart';
import 'monthly_goal.dart';

class GoalProvider extends ChangeNotifier {
  List<MonthlyGoal> _all = <MonthlyGoal>[];
  MonthlyGoal? _current;

  MonthlyGoal? get current => _current;
  List<MonthlyGoal> get allGoals => List<MonthlyGoal>.unmodifiable(_all);
  bool get hasGoal => _current != null;
  int get targetHours => _current?.targetHours ?? 0;

  Future<void> load() async {
    final list = <MonthlyGoal>[];
    for (final raw in LocalDb.goalBox.values) {
      try {
        final decoded = jsonDecode(raw);
        if (decoded is Map<String, dynamic>) {
          list.add(MonthlyGoal.fromJson(decoded));
        }
      } catch (_) {
        // skip broken goal
      }
    }
    _all = list;
    final now = DateTime.now();
    _current = null;
    for (final g in list) {
      if (g.year == now.year && g.month == now.month) {
        _current = g;
      }
    }
    notifyListeners();
  }

  Future<void> setGoal(int hours) async {
    if (hours <= 0) return;
    final now = DateTime.now();
    final goal =
        MonthlyGoal(year: now.year, month: now.month, targetHours: hours);
    await LocalDb.goalBox.put(goal.key, jsonEncode(goal.toJson()));
    await load();
  }

  Future<void> importGoals(List<MonthlyGoal> goals) async {
    await LocalDb.goalBox.putAll({
      for (final g in goals) g.key: jsonEncode(g.toJson()),
    });
    await load();
  }
}
