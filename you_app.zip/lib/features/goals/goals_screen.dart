import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../core/localization/app_strings.dart';
import '../../core/utils/date_utils.dart';
import '../../core/utils/duration_utils.dart';
import '../../core/widgets/common_widgets.dart';
import '../profile/settings_provider.dart';
import '../study/study_provider.dart';
import 'goal_provider.dart';

/// Dialog to set this month's goal. Also used from the Profile screen.
Future<void> showSetGoalDialog(BuildContext context, int currentHours) async {
  final provider = context.read<GoalProvider>();
  final controller = TextEditingController(
    text: currentHours > 0 ? '$currentHours' : '',
  );

  final result = await showDialog<int>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(ctx.tr('setMonthlyGoal')),
      content: TextField(
        controller: controller,
        keyboardType: TextInputType.number,
        inputFormatters: [FilteringTextInputFormatter.digitsOnly],
        autofocus: true,
        decoration: InputDecoration(
          labelText: ctx.tr('goalHours'),
          suffixText: ctx.tr('unitH'),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(ctx).pop(),
          child: Text(ctx.tr('cancel')),
        ),
        FilledButton(
          onPressed: () =>
              Navigator.of(ctx).pop(int.tryParse(controller.text.trim())),
          child: Text(ctx.tr('saveGoal')),
        ),
      ],
    ),
  );
  controller.dispose();

  if (result != null && result > 0 && result <= 744) {
    await provider.setGoal(result);
  }
}

class GoalsScreen extends StatelessWidget {
  const GoalsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final study = context.watch<StudyProvider>();
    final goal = context.watch<GoalProvider>();
    final locale = context.watch<SettingsProvider>().languageCode;

    final monthMinutes = study.monthMinutes;
    final targetHours = goal.targetHours;
    final targetMinutes = targetHours * 60;
    final progress = targetMinutes > 0
        ? (monthMinutes / targetMinutes).clamp(0.0, 1.0).toDouble()
        : 0.0;
    final remaining =
        (targetMinutes - monthMinutes).clamp(0, targetMinutes).toInt();
    final percent = (progress * 100).toStringAsFixed(0);

    return Scaffold(
      appBar: AppBar(
        title: Text(context.tr('goals')),
        actions: [
          IconButton(
            tooltip: context.tr('setMonthlyGoal'),
            icon: const Icon(Icons.edit_outlined),
            onPressed: () => showSetGoalDialog(context, targetHours),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
        children: [
          Text(
            AppDateUtils.formatMonthYear(DateTime.now(), locale),
            style: theme.textTheme.titleMedium
                ?.copyWith(fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 12),
          if (targetHours <= 0)
            EmptyState(
              icon: Icons.flag_outlined,
              title: context.tr('noGoalSet'),
              subtitle: context.tr('setAGoalToTrack'),
              actionLabel: context.tr('setGoal'),
              onAction: () => showSetGoalDialog(context, 0),
            )
          else ...[
            AppCard(
              padding: const EdgeInsets.all(20),
              child: SizedBox(
                width: double.infinity,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      context.tr('currentProgress'),
                      style: theme.textTheme.titleSmall
                          ?.copyWith(fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(height: 16),
                    Center(
                      child: SizedBox(
                        width: 140,
                        height: 140,
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            SizedBox(
                              width: 140,
                              height: 140,
                              child: CircularProgressIndicator(
                                value: progress,
                                strokeWidth: 12,
                                backgroundColor:
                                    scheme.surfaceContainerHighest,
                              ),
                            ),
                            Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  '$percent%',
                                  style: theme.textTheme.headlineSmall
                                      ?.copyWith(
                                    fontWeight: FontWeight.w700,
                                    color: scheme.primary,
                                  ),
                                ),
                                Text(
                                  context.tr('done'),
                                  style: theme.textTheme.bodySmall?.copyWith(
                                      color: scheme.onSurfaceVariant),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    _Row(
                      label: context.tr('done'),
                      value: AppDurationUtils.formatHours(
                          context, monthMinutes),
                    ),
                    const SizedBox(height: 8),
                    _Row(
                      label: context.tr('monthlyGoal'),
                      value: '$targetHours${context.tr('unitH')}',
                    ),
                    const SizedBox(height: 8),
                    _Row(
                      label: context.tr('remaining'),
                      value:
                          AppDurationUtils.formatHours(context, remaining),
                    ),
                  ],
                ),
              ),
            ),
          ],
          const SizedBox(height: 16),
          AppCard(
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.local_fire_department,
                      color: Colors.orange),
                  title: Text(context.tr('currentStreak')),
                  trailing: Text(
                    context.tr('daysCount', {'n': '${study.currentStreak}'}),
                    style: theme.textTheme.titleSmall
                        ?.copyWith(fontWeight: FontWeight.w700),
                  ),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: Icon(Icons.emoji_events_outlined,
                      color: scheme.primary),
                  title: Text(context.tr('longestStreak')),
                  trailing: Text(
                    context.tr('daysCount', {'n': '${study.longestStreak}'}),
                    style: theme.textTheme.titleSmall
                        ?.copyWith(fontWeight: FontWeight.w700),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Row extends StatelessWidget {
  const _Row({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Row(
      children: [
        Expanded(
          child: Text(
            label,
            style: theme.textTheme.bodyMedium
                ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
          ),
        ),
        Text(
          value,
          style: theme.textTheme.titleSmall
              ?.copyWith(fontWeight: FontWeight.w700),
        ),
      ],
    );
  }
}
