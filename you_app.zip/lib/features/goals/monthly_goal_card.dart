import 'package:flutter/material.dart';

import '../../core/localization/app_strings.dart';
import '../../core/utils/duration_utils.dart';
import '../../core/widgets/common_widgets.dart';

class MonthlyGoalCard extends StatelessWidget {
  const MonthlyGoalCard({
    super.key,
    required this.monthMinutes,
    required this.goalHours,
    this.onTap,
  });

  final int monthMinutes;
  final int goalHours;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final hasGoal = goalHours > 0;
    final progress = hasGoal
        ? (monthMinutes / (goalHours * 60)).clamp(0.0, 1.0).toDouble()
        : 0.0;
    final hUnit = context.tr('unitH');
    final done = AppDurationUtils.formatHours(context, monthMinutes);

    return ProgressCard(
      icon: Icons.flag_outlined,
      title: context.tr('monthlyGoal'),
      trailing: hasGoal
          ? '${(progress * 100).toStringAsFixed(0)}%'
          : context.tr('goalNotSet'),
      progress: progress,
      caption: hasGoal
          ? '$done ${context.tr('ofGoal')} $goalHours$hUnit'
          : done,
      onTap: onTap,
    );
  }
}
