import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/constants/subjects.dart';
import '../../core/localization/app_strings.dart';
import '../../core/widgets/common_widgets.dart';
import '../study/study_provider.dart';
import 'revision_provider.dart';

class RevisionView extends StatelessWidget {
  const RevisionView({super.key});

  Future<void> _mark(BuildContext context, RevisionItem item) async {
    final provider = context.read<RevisionProvider>();
    final messenger = ScaffoldMessenger.of(context);
    final okMsg = context.tr('revisionMarked');
    final errMsg = context.tr('genericError');
    try {
      await provider.markRevised(item.key);
      messenger.showSnackBar(SnackBar(content: Text(okMsg)));
    } catch (_) {
      messenger.showSnackBar(SnackBar(content: Text(errMsg)));
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final study = context.watch<StudyProvider>();
    final revision = context.watch<RevisionProvider>();
    final items = revision.buildItems(study.allRecords);

    if (items.isEmpty) {
      return EmptyState(
        icon: Icons.replay,
        title: context.tr('revisionEmpty'),
        subtitle: context.tr('revisionEmptyHint'),
      );
    }

    final red = items.where((i) => i.level == RevisionLevel.red).length;
    final yellow = items.where((i) => i.level == RevisionLevel.yellow).length;
    final needs = items.where((i) => i.level != RevisionLevel.green).toList();
    final good = items.where((i) => i.level == RevisionLevel.green).toList();

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
      children: [
        Wrap(
          spacing: 8,
          runSpacing: 4,
          children: [
            _CountChip(color: scheme.error, text: '$red'),
            _CountChip(color: const Color(0xFFF9A825), text: '$yellow'),
            _CountChip(color: scheme.primary, text: '${good.length}'),
          ],
        ),
        const SizedBox(height: 8),
        Text(
          context.tr('revisionNote'),
          style: theme.textTheme.bodySmall
              ?.copyWith(color: scheme.onSurfaceVariant),
        ),
        SectionHeader(context.tr('needsRevision')),
        if (needs.isEmpty)
          Text(
            context.tr('nothingToRevise'),
            style: theme.textTheme.bodyMedium
                ?.copyWith(color: scheme.onSurfaceVariant),
          )
        else
          for (final item in needs)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: _RevisionCard(
                item: item,
                onMark: () => _mark(context, item),
              ),
            ),
        if (good.isNotEmpty) ...[
          SectionHeader('${context.tr('goodTopics')} (${good.length})'),
          for (final item in good)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: _RevisionCard(
                item: item,
                onMark: () => _mark(context, item),
              ),
            ),
        ],
      ],
    );
  }
}

Color _levelColor(BuildContext context, RevisionLevel level) {
  switch (level) {
    case RevisionLevel.red:
      return Theme.of(context).colorScheme.error;
    case RevisionLevel.yellow:
      return const Color(0xFFF9A825);
    case RevisionLevel.green:
      return Theme.of(context).colorScheme.primary;
  }
}

class _CountChip extends StatelessWidget {
  const _CountChip({required this.color, required this.text});

  final Color color;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Chip(
      avatar: CircleAvatar(backgroundColor: color, radius: 6),
      label: Text(text),
      visualDensity: VisualDensity.compact,
    );
  }
}

class _RevisionCard extends StatelessWidget {
  const _RevisionCard({required this.item, required this.onMark});

  final RevisionItem item;
  final VoidCallback onMark;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final color = _levelColor(context, item.level);
    final reason = context.tr(item.reasonKey, {'n': '${item.days}'});

    return AppCard(
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 5),
                child: CircleAvatar(backgroundColor: color, radius: 6),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item.topic,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: theme.textTheme.titleSmall
                          ?.copyWith(fontWeight: FontWeight.w700),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '${Subjects.icon(item.subject)} '
                      '${Subjects.label(context, item.subject)}',
                      style: theme.textTheme.bodySmall
                          ?.copyWith(color: scheme.onSurfaceVariant),
                    ),
                    const SizedBox(height: 4),
                    Text(reason, style: theme.textTheme.bodySmall),
                  ],
                ),
              ),
            ],
          ),
          Align(
            alignment: Alignment.centerRight,
            child: TextButton.icon(
              onPressed: onMark,
              icon: const Icon(Icons.check_circle_outline, size: 18),
              label: Text(context.tr('markRevised')),
            ),
          ),
        ],
      ),
    );
  }
}
