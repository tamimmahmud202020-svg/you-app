import 'package:flutter/foundation.dart';

import '../../core/storage/local_db.dart';
import '../../core/utils/date_utils.dart';
import '../study/study_record.dart';

enum RevisionLevel { red, yellow, green }

class RevisionItem {
  const RevisionItem({
    required this.key,
    required this.subject,
    required this.topic,
    required this.lastStudied,
    required this.lastRevised,
    required this.days,
    required this.level,
    required this.reasonKey,
  });

  final String key;
  final String subject;
  final String topic;
  final DateTime lastStudied;
  final DateTime? lastRevised;
  final int days; // days since last study or revision
  final RevisionLevel level;
  final String reasonKey; // localisation key, uses {n} = days
}

/// Decides which topics need revision, using study history and the dates the
/// user pressed "Mark revised". (Exam mistakes will be added with the exam.)
class RevisionProvider extends ChangeNotifier {
  Map<String, DateTime> _revised = <String, DateTime>{};

  Map<String, DateTime> get revisedMap =>
      Map<String, DateTime>.unmodifiable(_revised);

  Future<void> load() async {
    final map = <String, DateTime>{};
    final box = LocalDb.revisionBox;
    for (final key in box.keys) {
      final value = DateTime.tryParse(box.get(key) ?? '');
      if (key is String && value != null) map[key] = value;
    }
    _revised = map;
    notifyListeners();
  }

  Future<void> markRevised(String topicKey) async {
    await LocalDb.revisionBox.put(topicKey, DateTime.now().toIso8601String());
    await load();
  }

  Future<void> importRevisions(Map<String, DateTime> imported) async {
    for (final e in imported.entries) {
      final current = _revised[e.key];
      if (current == null || e.value.isAfter(current)) {
        await LocalDb.revisionBox.put(e.key, e.value.toIso8601String());
      }
    }
    await load();
  }

  List<RevisionItem> buildItems(List<StudyRecord> records, {DateTime? now}) {
    final today = AppDateUtils.startOfDay(now ?? DateTime.now());
    final groups = <String, List<StudyRecord>>{};
    for (final r in records) {
      groups.putIfAbsent(r.topicKey, () => <StudyRecord>[]).add(r);
    }

    final items = <RevisionItem>[];
    groups.forEach((key, list) {
      var latest = list.first;
      for (final r in list) {
        final newer = r.date.isAfter(latest.date) ||
            (r.date == latest.date && r.createdAt.isAfter(latest.createdAt));
        if (newer) latest = r;
      }

      final lastStudied = AppDateUtils.startOfDay(latest.date);
      final revisedRaw = _revised[key];
      final lastRevised =
          revisedRaw == null ? null : AppDateUtils.startOfDay(revisedRaw);

      var reference = lastStudied;
      if (lastRevised != null && lastRevised.isAfter(reference)) {
        reference = lastRevised;
      }
      var days = DateTime.utc(today.year, today.month, today.day)
          .difference(
              DateTime.utc(reference.year, reference.month, reference.day))
          .inDays;
      if (days < 0) days = 0;

      final hard = latest.difficulty == 2;
      final incomplete = !latest.completed;
      final weak = hard || incomplete;
      final weakReason = hard ? 'reasonHard' : 'reasonIncomplete';

      RevisionLevel level;
      String reasonKey;
      if (days >= 14 || (days >= 7 && weak)) {
        level = RevisionLevel.red;
        reasonKey = days >= 14 ? 'reasonOld' : weakReason;
      } else if (days >= 7 || (weak && days >= 3)) {
        level = RevisionLevel.yellow;
        reasonKey = days >= 7 ? 'reasonOld' : weakReason;
      } else {
        level = RevisionLevel.green;
        reasonKey = days == 0 ? 'reasonToday' : 'reasonGood';
      }

      items.add(RevisionItem(
        key: key,
        subject: latest.subject,
        topic: latest.topic,
        lastStudied: lastStudied,
        lastRevised: lastRevised,
        days: days,
        level: level,
        reasonKey: reasonKey,
      ));
    });

    items.sort((a, b) {
      final byLevel = a.level.index.compareTo(b.level.index);
      if (byLevel != 0) return byLevel;
      return a.level == RevisionLevel.green
          ? a.days.compareTo(b.days)
          : b.days.compareTo(a.days);
    });
    return items;
  }
}
