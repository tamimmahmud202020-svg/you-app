import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/constants/subjects.dart';
import '../../core/localization/app_strings.dart';
import '../../core/utils/date_utils.dart';
import '../../core/utils/duration_utils.dart';
import '../../core/widgets/common_widgets.dart';
import '../profile/settings_provider.dart';
import 'study_record.dart';

class StudyCard extends StatelessWidget {
  const StudyCard({
    super.key,
    required this.record,
    this.onTap,
    this.onEdit,
    this.onDuplicate,
    this.onDelete,
  });

  final StudyRecord record;
  final VoidCallback? onTap;
  final VoidCallback? onEdit;
  final VoidCallback? onDuplicate;
  final VoidCallback? onDelete;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final locale = context.watch<SettingsProvider>().languageCode;

    final subjectLabel = Subjects.label(context, record.subject);
    final subtitle = record.subTopic.isEmpty
        ? subjectLabel
        : '$subjectLabel · ${record.subTopic}';
    final difficultyKey = const ['easy', 'medium', 'hard'][
        record.difficulty < 0 ? 0 : (record.difficulty > 2 ? 2 : record.difficulty)];
    final showMenu =
        onEdit != null || onDuplicate != null || onDelete != null;

    return AppCard(
      onTap: onTap,
      padding: const EdgeInsets.all(12),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: scheme.primaryContainer,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              Subjects.icon(record.subject),
              style: const TextStyle(fontSize: 20),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  record.topic,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: theme.textTheme.titleSmall
                      ?.copyWith(fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: theme.textTheme.bodySmall
                      ?.copyWith(color: scheme.onSurfaceVariant),
                ),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 12,
                  runSpacing: 2,
                  children: [
                    _Meta(
                      icon: Icons.schedule,
                      text: AppDurationUtils.formatMinutes(
                          context, record.durationMinutes),
                    ),
                    _Meta(
                      icon: Icons.calendar_today_outlined,
                      text: AppDateUtils.formatShort(record.date, locale),
                    ),
                    _Meta(
                      icon: Icons.speed,
                      text: context.tr(difficultyKey),
                    ),
                    _Meta(
                      icon: record.completed
                          ? Icons.check_circle_outline
                          : Icons.hourglass_empty,
                      text: record.completed ? context.tr('completed') : '…',
                    ),
                  ],
                ),
              ],
            ),
          ),
          if (showMenu)
            PopupMenuButton<String>(
              icon: Icon(Icons.more_vert, color: scheme.onSurfaceVariant),
              onSelected: (value) {
                switch (value) {
                  case 'edit':
                    onEdit?.call();
                    break;
                  case 'duplicate':
                    onDuplicate?.call();
                    break;
                  case 'delete':
                    onDelete?.call();
                    break;
                }
              },
              itemBuilder: (ctx) => [
                if (onEdit != null)
                  PopupMenuItem<String>(
                    value: 'edit',
                    child: Text(ctx.tr('edit')),
                  ),
                if (onDuplicate != null)
                  PopupMenuItem<String>(
                    value: 'duplicate',
                    child: Text(ctx.tr('duplicate')),
                  ),
                if (onDelete != null)
                  PopupMenuItem<String>(
                    value: 'delete',
                    child: Text(ctx.tr('delete')),
                  ),
              ],
            ),
        ],
      ),
    );
  }
}

class _Meta extends StatelessWidget {
  const _Meta({required this.icon, required this.text});

  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final color = theme.colorScheme.onSurfaceVariant;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 13, color: color),
        const SizedBox(width: 4),
        Text(text, style: theme.textTheme.labelSmall?.copyWith(color: color)),
      ],
    );
  }
}
