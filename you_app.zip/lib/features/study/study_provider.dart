import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';

import '../../core/utils/date_utils.dart';
import 'study_record.dart';
import 'study_repository.dart';

enum StudyFilter { all, today, thisWeek, thisMonth, subject }

enum StudySort { newest, oldest, longest }

class StudyProvider extends ChangeNotifier {
  final StudyRepository _repository = StudyRepository();
  final Uuid _uuid = const Uuid();

  List<StudyRecord> _all = <StudyRecord>[];
  Set<DateTime> _studyDays = <DateTime>{};
  Map<DateTime, int> _minutesByDay = <DateTime, int>{};
  bool _loading = true;
  String? _errorKey;

  String _query = '';
  StudyFilter _filter = StudyFilter.all;
  StudySort _sort = StudySort.newest;
  String? _subjectFilter;

  bool get isLoading => _loading;
  String? get errorKey => _errorKey;
  List<StudyRecord> get allRecords => List<StudyRecord>.unmodifiable(_all);
  bool get isEmpty => _all.isEmpty;
  String get query => _query;
  StudyFilter get filter => _filter;
  StudySort get sort => _sort;
  String? get subjectFilter => _subjectFilter;

  // ---------- loading ----------

  Future<void> load() async {
    try {
      _all = _repository.getAll();
      _errorKey = null;
    } catch (_) {
      _all = <StudyRecord>[];
      _errorKey = 'loadError';
    }
    _rebuildCaches();
    _loading = false;
    notifyListeners();
  }

  void _rebuildCaches() {
    final days = <DateTime>{};
    final minutes = <DateTime, int>{};
    for (final r in _all) {
      final d = AppDateUtils.startOfDay(r.date);
      days.add(d);
      minutes[d] = (minutes[d] ?? 0) + r.durationMinutes;
    }
    _studyDays = days;
    _minutesByDay = minutes;
  }

  // ---------- search / filter / sort ----------

  List<StudyRecord> visibleRecords({
    String Function(String subject)? subjectLabel,
  }) {
    final now = DateTime.now();
    final today = AppDateUtils.startOfDay(now);
    // Weeks start on Saturday in Bangladesh.
    final weekStart = DateTime(
      today.year,
      today.month,
      today.day - ((today.weekday + 1) % 7),
    );
    final monthStart = DateTime(now.year, now.month, 1);
    final nextMonthStart = DateTime(now.year, now.month + 1, 1);
    final q = _query.trim().toLowerCase();

    final result = <StudyRecord>[];
    for (final r in _all) {
      if (q.isNotEmpty) {
        final label = subjectLabel == null ? '' : subjectLabel(r.subject);
        final hay =
            '${r.subject} $label ${r.topic} ${r.subTopic} ${r.notes}'
                .toLowerCase();
        if (!hay.contains(q)) continue;
      }

      switch (_filter) {
        case StudyFilter.today:
          if (!AppDateUtils.isSameDay(r.date, now)) continue;
          break;
        case StudyFilter.thisWeek:
          if (r.date.isBefore(weekStart)) continue;
          break;
        case StudyFilter.thisMonth:
          if (r.date.isBefore(monthStart)) continue;
          if (!r.date.isBefore(nextMonthStart)) continue;
          break;
        case StudyFilter.subject:
          if (_subjectFilter != null && r.subject != _subjectFilter) {
            continue;
          }
          break;
        case StudyFilter.all:
          break;
      }
      result.add(r);
    }

    switch (_sort) {
      case StudySort.newest:
        result.sort((a, b) {
          final c = b.date.compareTo(a.date);
          return c != 0 ? c : b.createdAt.compareTo(a.createdAt);
        });
        break;
      case StudySort.oldest:
        result.sort((a, b) {
          final c = a.date.compareTo(b.date);
          return c != 0 ? c : a.createdAt.compareTo(b.createdAt);
        });
        break;
      case StudySort.longest:
        result.sort((a, b) => b.durationMinutes.compareTo(a.durationMinutes));
        break;
    }
    return result;
  }

  List<String> get usedSubjects {
    final set = <String>{for (final r in _all) r.subject};
    final list = set.toList()..sort();
    return list;
  }

  void setQuery(String value) {
    if (_query == value) return;
    _query = value;
    notifyListeners();
  }

  void setFilter(StudyFilter value) {
    _filter = value;
    if (value != StudyFilter.subject) _subjectFilter = null;
    notifyListeners();
  }

  void setSort(StudySort value) {
    if (_sort == value) return;
    _sort = value;
    notifyListeners();
  }

  void setSubjectFilter(String? subject) {
    _subjectFilter = subject;
    _filter = subject == null ? StudyFilter.all : StudyFilter.subject;
    notifyListeners();
  }

  void clearFilters() {
    _query = '';
    _filter = StudyFilter.all;
    _sort = StudySort.newest;
    _subjectFilter = null;
    notifyListeners();
  }

  // ---------- statistics ----------

  List<StudyRecord> recordsForDay(DateTime day) =>
      _all.where((r) => AppDateUtils.isSameDay(r.date, day)).toList();

  int minutesOn(DateTime day) =>
      _minutesByDay[AppDateUtils.startOfDay(day)] ?? 0;

  bool hasStudyOn(DateTime day) =>
      _studyDays.contains(AppDateUtils.startOfDay(day));

  List<StudyRecord> get todayRecords => recordsForDay(DateTime.now());

  int get todayMinutes => minutesOn(DateTime.now());

  int get todaySessions => todayRecords.length;

  int get todayTopics =>
      todayRecords.map((r) => '${r.subject}|${r.topic}').toSet().length;

  int get monthMinutes {
    final now = DateTime.now();
    return _all
        .where((r) => r.date.year == now.year && r.date.month == now.month)
        .fold(0, (sum, r) => sum + r.durationMinutes);
  }

  int get totalMinutes => _all.fold(0, (sum, r) => sum + r.durationMinutes);

  int get totalStudyDays => _studyDays.length;

  /// Consecutive study days ending today (or yesterday if nothing yet today).
  int get currentStreak {
    if (_studyDays.isEmpty) return 0;
    final now = DateTime.now();
    var cursor = DateTime(now.year, now.month, now.day);
    if (!_studyDays.contains(cursor)) {
      cursor = DateTime(cursor.year, cursor.month, cursor.day - 1);
      if (!_studyDays.contains(cursor)) return 0;
    }
    var streak = 0;
    while (_studyDays.contains(cursor)) {
      streak++;
      cursor = DateTime(cursor.year, cursor.month, cursor.day - 1);
    }
    return streak;
  }

  int get longestStreak {
    if (_studyDays.isEmpty) return 0;
    final days = _studyDays.toList()..sort();
    var longest = 1;
    var current = 1;
    for (var i = 1; i < days.length; i++) {
      final expectedNext =
          DateTime(days[i - 1].year, days[i - 1].month, days[i - 1].day + 1);
      if (days[i] == expectedNext) {
        current++;
        if (current > longest) longest = current;
      } else {
        current = 1;
      }
    }
    return longest;
  }

  // ---------- changes (screens catch errors and show a message) ----------

  Future<StudyRecord> addRecord({
    required String subject,
    required String topic,
    String subTopic = '',
    required DateTime date,
    required int durationMinutes,
    String notes = '',
    int difficulty = 1,
    bool completed = true,
    String personalNote = '',
  }) async {
    final now = DateTime.now();
    final record = StudyRecord(
      id: _uuid.v4(),
      subject: subject,
      topic: topic,
      subTopic: subTopic,
      date: AppDateUtils.startOfDay(date),
      durationMinutes: durationMinutes,
      notes: notes,
      difficulty: difficulty,
      completed: completed,
      personalNote: personalNote,
      createdAt: now,
      updatedAt: now,
    );
    await _repository.put(record);
    await load();
    return record;
  }

  Future<void> updateRecord(StudyRecord record) async {
    await _repository.put(record.copyWith(
      date: AppDateUtils.startOfDay(record.date),
      updatedAt: DateTime.now(),
    ));
    await load();
  }

  Future<void> deleteRecord(String id) async {
    await _repository.delete(id);
    await load();
  }

  Future<void> duplicateRecord(StudyRecord source) async {
    final now = DateTime.now();
    final copy = StudyRecord(
      id: _uuid.v4(),
      subject: source.subject,
      topic: source.topic,
      subTopic: source.subTopic,
      date: AppDateUtils.startOfDay(now),
      durationMinutes: source.durationMinutes,
      notes: source.notes,
      difficulty: source.difficulty,
      completed: source.completed,
      personalNote: source.personalNote,
      createdAt: now,
      updatedAt: now,
    );
    await _repository.put(copy);
    await load();
  }

  Future<int> importRecords(List<StudyRecord> records) async {
    await _repository.putAll(records);
    await load();
    return records.length;
  }
}
