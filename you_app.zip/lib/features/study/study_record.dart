class StudyRecord {
  const StudyRecord({
    required this.id,
    required this.subject,
    required this.topic,
    this.subTopic = '',
    required this.date,
    required this.durationMinutes,
    this.notes = '',
    this.difficulty = 1,
    this.completed = true,
    this.personalNote = '',
    required this.createdAt,
    required this.updatedAt,
  });

  final String id;
  final String subject; // stable English id, or a custom subject name
  final String topic;
  final String subTopic;
  final DateTime date; // date only
  final int durationMinutes;
  final String notes;
  final int difficulty; // 0 easy, 1 medium, 2 hard
  final bool completed;
  final String personalNote;
  final DateTime createdAt;
  final DateTime updatedAt;

  StudyRecord copyWith({
    String? subject,
    String? topic,
    String? subTopic,
    DateTime? date,
    int? durationMinutes,
    String? notes,
    int? difficulty,
    bool? completed,
    String? personalNote,
    DateTime? updatedAt,
  }) {
    return StudyRecord(
      id: id,
      subject: subject ?? this.subject,
      topic: topic ?? this.topic,
      subTopic: subTopic ?? this.subTopic,
      date: date ?? this.date,
      durationMinutes: durationMinutes ?? this.durationMinutes,
      notes: notes ?? this.notes,
      difficulty: difficulty ?? this.difficulty,
      completed: completed ?? this.completed,
      personalNote: personalNote ?? this.personalNote,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'subject': subject,
        'topic': topic,
        'subTopic': subTopic,
        'date': date.toIso8601String(),
        'durationMinutes': durationMinutes,
        'notes': notes,
        'difficulty': difficulty,
        'completed': completed,
        'personalNote': personalNote,
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
      };

  /// Throws if id / subject / topic / date are missing or broken.
  /// Callers skip such records instead of crashing.
  factory StudyRecord.fromJson(Map<String, dynamic> json) {
    final id = json['id'];
    final subject = json['subject'];
    final topic = json['topic'];
    final date = DateTime.parse(json['date'] as String);
    if (id is! String || id.isEmpty) {
      throw const FormatException('Record has no id');
    }
    if (subject is! String || subject.isEmpty) {
      throw const FormatException('Record has no subject');
    }
    if (topic is! String || topic.isEmpty) {
      throw const FormatException('Record has no topic');
    }
    final duration = (json['durationMinutes'] as num?)?.toInt() ?? 0;
    final difficulty = (json['difficulty'] as num?)?.toInt() ?? 1;
    return StudyRecord(
      id: id,
      subject: subject,
      topic: topic,
      subTopic: (json['subTopic'] as String?) ?? '',
      date: DateTime(date.year, date.month, date.day),
      durationMinutes: duration < 0 ? 0 : duration,
      notes: (json['notes'] as String?) ?? '',
      difficulty: difficulty < 0 ? 0 : (difficulty > 2 ? 2 : difficulty),
      completed: (json['completed'] as bool?) ?? true,
      personalNote: (json['personalNote'] as String?) ?? '',
      createdAt: DateTime.tryParse((json['createdAt'] as String?) ?? '') ??
          DateTime.now(),
      updatedAt: DateTime.tryParse((json['updatedAt'] as String?) ?? '') ??
          DateTime.now(),
    );
  }
}
