import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../core/constants/subjects.dart';
import '../../core/localization/app_strings.dart';
import '../../core/utils/date_utils.dart';
import '../../core/widgets/common_widgets.dart';
import '../profile/settings_provider.dart';
import 'study_provider.dart';
import 'study_record.dart';

class AddStudyScreen extends StatefulWidget {
  const AddStudyScreen({super.key, this.existing, this.initialDate});

  final StudyRecord? existing;
  final DateTime? initialDate;

  @override
  State<AddStudyScreen> createState() => _AddStudyScreenState();
}

class _AddStudyScreenState extends State<AddStudyScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _topic;
  late final TextEditingController _subTopic;
  late final TextEditingController _notes;
  late final TextEditingController _personal;
  late final TextEditingController _hours;
  late final TextEditingController _minutes;

  late String _subject;
  late DateTime _date;
  int _difficulty = 1;
  bool _completed = true;
  bool _saving = false;

  bool get _isEdit => widget.existing != null;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _topic = TextEditingController(text: e?.topic ?? '');
    _subTopic = TextEditingController(text: e?.subTopic ?? '');
    _notes = TextEditingController(text: e?.notes ?? '');
    _personal = TextEditingController(text: e?.personalNote ?? '');
    final minutes = e?.durationMinutes ?? 30;
    _hours = TextEditingController(text: '${minutes ~/ 60}');
    _minutes = TextEditingController(text: '${minutes % 60}');
    _subject = e?.subject ?? Subjects.defaults.first;
    _difficulty = e?.difficulty ?? 1;
    _completed = e?.completed ?? true;

    final today = AppDateUtils.startOfDay(DateTime.now());
    final wanted = e?.date ?? widget.initialDate ?? today;
    final day = AppDateUtils.startOfDay(wanted);
    _date = (e == null && day.isAfter(today)) ? today : day;
  }

  @override
  void dispose() {
    _topic.dispose();
    _subTopic.dispose();
    _notes.dispose();
    _personal.dispose();
    _hours.dispose();
    _minutes.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final today = AppDateUtils.startOfDay(DateTime.now());
    final first = _date.isBefore(DateTime(2000)) ? _date : DateTime(2000);
    final last = _date.isAfter(today) ? _date : today;
    final picked = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: first,
      lastDate: last,
    );
    if (picked != null && mounted) {
      setState(() => _date = AppDateUtils.startOfDay(picked));
    }
  }

  Future<void> _addSubject() async {
    final controller = TextEditingController();
    final settings = context.read<SettingsProvider>();
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(ctx.tr('addSubject')),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: InputDecoration(labelText: ctx.tr('subjectName')),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: Text(ctx.tr('cancel')),
          ),
          FilledButton(
            onPressed: () => Navigator.of(ctx).pop(controller.text.trim()),
            child: Text(ctx.tr('add')),
          ),
        ],
      ),
    );
    controller.dispose();
    if (name != null && name.isNotEmpty) {
      await settings.addCustomSubject(name);
      if (mounted) setState(() => _subject = name);
    }
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;

    final provider = context.read<StudyProvider>();
    final navigator = Navigator.of(context);
    final messenger = ScaffoldMessenger.of(context);
    final addedMsg = context.tr('recordAdded');
    final updatedMsg = context.tr('recordUpdated');
    final errorMsg = context.tr('saveError');

    final hours = int.tryParse(_hours.text.trim()) ?? 0;
    final minutes = int.tryParse(_minutes.text.trim()) ?? 0;
    final total = hours * 60 + minutes;

    setState(() => _saving = true);
    try {
      final existing = widget.existing;
      if (existing != null) {
        await provider.updateRecord(existing.copyWith(
          subject: _subject,
          topic: _topic.text.trim(),
          subTopic: _subTopic.text.trim(),
          date: _date,
          durationMinutes: total,
          notes: _notes.text.trim(),
          difficulty: _difficulty,
          completed: _completed,
          personalNote: _personal.text.trim(),
        ));
      } else {
        await provider.addRecord(
          subject: _subject,
          topic: _topic.text.trim(),
          subTopic: _subTopic.text.trim(),
          date: _date,
          durationMinutes: total,
          notes: _notes.text.trim(),
          difficulty: _difficulty,
          completed: _completed,
          personalNote: _personal.text.trim(),
        );
      }
      messenger.showSnackBar(
        SnackBar(content: Text(existing != null ? updatedMsg : addedMsg)),
      );
      navigator.pop();
    } catch (_) {
      if (mounted) {
        setState(() => _saving = false);
        messenger.showSnackBar(SnackBar(content: Text(errorMsg)));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsProvider>();
    final subjects = Subjects.withCustom(settings.customSubjects);
    if (!subjects.contains(_subject)) subjects.add(_subject);

    return Scaffold(
      appBar: AppBar(
        title: Text(context.tr(_isEdit ? 'editStudy' : 'addStudy')),
      ),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: ListView(
            keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
            children: [
              _Label(context.tr('date')),
              InkWell(
                onTap: _saving ? null : _pickDate,
                borderRadius: BorderRadius.circular(12),
                child: InputDecorator(
                  decoration: const InputDecoration(
                    prefixIcon: Icon(Icons.calendar_today_outlined),
                  ),
                  child: Text(
                    AppDateUtils.formatFull(_date, settings.languageCode),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              _Label(context.tr('subject')),
              Wrap(
                spacing: 8,
                runSpacing: 4,
                children: [
                  for (final s in subjects)
                    ChoiceChip(
                      label: Text(
                        '${Subjects.icon(s)} ${Subjects.label(context, s)}',
                      ),
                      selected: _subject == s,
                      onSelected:
                          _saving ? null : (_) => setState(() => _subject = s),
                    ),
                  ActionChip(
                    avatar: const Icon(Icons.add, size: 18),
                    label: Text(context.tr('addSubject')),
                    onPressed: _saving ? null : _addSubject,
                  ),
                ],
              ),
              const SizedBox(height: 16),
              _Label(context.tr('topic')),
              TextFormField(
                controller: _topic,
                textInputAction: TextInputAction.next,
                decoration: InputDecoration(
                  hintText: context.tr('enterTopic'),
                  prefixIcon: const Icon(Icons.topic_outlined),
                ),
                validator: (v) => (v == null || v.trim().isEmpty)
                    ? context.tr('fieldRequired', {'field': context.tr('topic')})
                    : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _subTopic,
                textInputAction: TextInputAction.next,
                decoration: InputDecoration(
                  labelText: context.tr('subTopic'),
                ),
              ),
              const SizedBox(height: 16),
              _Label(context.tr('notes')),
              TextFormField(
                controller: _notes,
                minLines: 3,
                maxLines: 6,
                keyboardType: TextInputType.multiline,
              ),
              const SizedBox(height: 16),
              _Label(context.tr('duration')),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: _hours,
                      keyboardType: TextInputType.number,
                      inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                      decoration: InputDecoration(
                        labelText: context.tr('hours'),
                        prefixIcon: const Icon(Icons.schedule),
                      ),
                      validator: (v) {
                        final h = int.tryParse((v ?? '').trim()) ?? 0;
                        final m = int.tryParse(_minutes.text.trim()) ?? 0;
                        if (h < 0 || h > 24) return context.tr('hoursRange');
                        if (h == 0 && m == 0) return context.tr('durationZero');
                        return null;
                      },
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextFormField(
                      controller: _minutes,
                      keyboardType: TextInputType.number,
                      inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                      decoration: InputDecoration(
                        labelText: context.tr('minutes'),
                      ),
                      validator: (v) {
                        final m = int.tryParse((v ?? '').trim()) ?? 0;
                        if (m < 0 || m > 59) return context.tr('minutesRange');
                        return null;
                      },
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              _Label(context.tr('difficulty')),
              Wrap(
                spacing: 8,
                children: [
                  for (final d in const [0, 1, 2])
                    ChoiceChip(
                      label: Text(context.tr(const ['easy', 'medium', 'hard'][d])),
                      selected: _difficulty == d,
                      onSelected:
                          _saving ? null : (_) => setState(() => _difficulty = d),
                    ),
                ],
              ),
              const SizedBox(height: 8),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: Text(context.tr('completed')),
                value: _completed,
                onChanged:
                    _saving ? null : (v) => setState(() => _completed = v),
              ),
              const SizedBox(height: 8),
              _Label(context.tr('personalNote')),
              TextFormField(
                controller: _personal,
                minLines: 2,
                maxLines: 4,
                keyboardType: TextInputType.multiline,
              ),
              const SizedBox(height: 24),
              FilledButton.icon(
                onPressed: _saving ? null : _save,
                icon: _saving
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : Icon(_isEdit ? Icons.check : Icons.add),
                label: Text(context.tr(_isEdit ? 'update' : 'save')),
                style: FilledButton.styleFrom(
                  minimumSize: const Size.fromHeight(52),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Label extends StatelessWidget {
  const _Label(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 4, bottom: 6),
      child: Text(
        text,
        style: Theme.of(context)
            .textTheme
            .labelLarge
            ?.copyWith(fontWeight: FontWeight.w600),
      ),
    );
  }
}
