import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/constants/subjects.dart';
import '../../core/localization/app_strings.dart';
import '../../core/widgets/common_widgets.dart';
import 'add_study_screen.dart';
import 'study_card.dart';
import 'study_provider.dart';
import 'study_record.dart';

class StudyHistoryScreen extends StatefulWidget {
  const StudyHistoryScreen({super.key});

  @override
  State<StudyHistoryScreen> createState() => _StudyHistoryScreenState();
}

class _StudyHistoryScreenState extends State<StudyHistoryScreen> {
  final TextEditingController _search = TextEditingController();

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  void _openAdd() {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => const AddStudyScreen()),
    );
  }

  void _openEdit(StudyRecord record) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => AddStudyScreen(existing: record),
      ),
    );
  }

  Future<void> _duplicate(StudyRecord record) async {
    final provider = context.read<StudyProvider>();
    final messenger = ScaffoldMessenger.of(context);
    final ok = context.tr('recordDuplicated');
    final err = context.tr('saveError');
    try {
      await provider.duplicateRecord(record);
      messenger.showSnackBar(SnackBar(content: Text(ok)));
    } catch (_) {
      messenger.showSnackBar(SnackBar(content: Text(err)));
    }
  }

  Future<void> _confirmDelete(StudyRecord record) async {
    final provider = context.read<StudyProvider>();
    final messenger = ScaffoldMessenger.of(context);
    final ok = context.tr('recordDeleted');
    final err = context.tr('saveError');
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(ctx.tr('deleteConfirmTitle')),
        content: Text(ctx.tr('deleteConfirmMessage')),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: Text(ctx.tr('cancel')),
          ),
          FilledButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: Text(ctx.tr('delete')),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    try {
      await provider.deleteRecord(record.id);
      messenger.showSnackBar(SnackBar(content: Text(ok)));
    } catch (_) {
      messenger.showSnackBar(SnackBar(content: Text(err)));
    }
  }

  Widget _chip({
    required String label,
    required bool selected,
    required VoidCallback onTap,
  }) {
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: FilterChip(
        label: Text(label),
        selected: selected,
        onSelected: (_) => onTap(),
        showCheckmark: false,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final study = context.watch<StudyProvider>();
    final records = study.visibleRecords(
      subjectLabel: (s) => Subjects.label(context, s),
    );
    final subjectSelected = study.filter == StudyFilter.subject;

    return Scaffold(
      appBar: AppBar(
        title: Text(context.tr('navStudy')),
        actions: [
          IconButton(
            tooltip: context.tr('clearFilters'),
            onPressed: () {
              _search.clear();
              study.clearFilters();
            },
            icon: const Icon(Icons.filter_alt_off_outlined),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _openAdd,
        icon: const Icon(Icons.add),
        label: Text(context.tr('addStudy')),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
            child: TextField(
              controller: _search,
              onChanged: study.setQuery,
              decoration: InputDecoration(
                hintText: context.tr('searchHint'),
                prefixIcon: const Icon(Icons.search),
                suffixIcon: study.query.isEmpty
                    ? null
                    : IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _search.clear();
                          study.setQuery('');
                        },
                      ),
              ),
            ),
          ),
          SizedBox(
            height: 44,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              children: [
                _chip(
                  label: context.tr('filterAll'),
                  selected: study.filter == StudyFilter.all,
                  onTap: () => study.setFilter(StudyFilter.all),
                ),
                _chip(
                  label: context.tr('filterToday'),
                  selected: study.filter == StudyFilter.today,
                  onTap: () => study.setFilter(StudyFilter.today),
                ),
                _chip(
                  label: context.tr('filterThisWeek'),
                  selected: study.filter == StudyFilter.thisWeek,
                  onTap: () => study.setFilter(StudyFilter.thisWeek),
                ),
                _chip(
                  label: context.tr('filterThisMonth'),
                  selected: study.filter == StudyFilter.thisMonth,
                  onTap: () => study.setFilter(StudyFilter.thisMonth),
                ),
                if (study.usedSubjects.isNotEmpty)
                  PopupMenuButton<String>(
                    onSelected: study.setSubjectFilter,
                    itemBuilder: (ctx) => [
                      for (final s in study.usedSubjects)
                        PopupMenuItem<String>(
                          value: s,
                          child: Text(
                            '${Subjects.icon(s)} ${Subjects.label(ctx, s)}',
                          ),
                        ),
                    ],
                    child: Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: Chip(
                        avatar: const Icon(Icons.arrow_drop_down, size: 20),
                        label: Text(
                          subjectSelected && study.subjectFilter != null
                              ? Subjects.label(context, study.subjectFilter!)
                              : context.tr('filterSubject'),
                        ),
                        backgroundColor:
                            subjectSelected ? scheme.secondaryContainer : null,
                      ),
                    ),
                  ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 8, 0),
            child: Row(
              children: [
                Text(
                  '${records.length}',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: scheme.onSurfaceVariant,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const Spacer(),
                PopupMenuButton<StudySort>(
                  initialValue: study.sort,
                  onSelected: study.setSort,
                  itemBuilder: (ctx) => [
                    PopupMenuItem<StudySort>(
                      value: StudySort.newest,
                      child: Text(ctx.tr('sortNewest')),
                    ),
                    PopupMenuItem<StudySort>(
                      value: StudySort.oldest,
                      child: Text(ctx.tr('sortOldest')),
                    ),
                    PopupMenuItem<StudySort>(
                      value: StudySort.longest,
                      child: Text(ctx.tr('sortLongest')),
                    ),
                  ],
                  child: Padding(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                    child: Row(
                      children: [
                        Icon(Icons.sort,
                            size: 18, color: scheme.onSurfaceVariant),
                        const SizedBox(width: 4),
                        Text(
                          context.tr('sortBy'),
                          style: theme.textTheme.bodySmall
                              ?.copyWith(color: scheme.onSurfaceVariant),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: records.isEmpty
                ? EmptyState(
                    icon: Icons.menu_book_outlined,
                    title: context.tr(
                        study.isEmpty ? 'noRecordsYet' : 'noResults'),
                    subtitle: context.tr(
                        study.isEmpty ? 'addFirstStudy' : 'tryDifferent'),
                    actionLabel:
                        study.isEmpty ? context.tr('addStudy') : null,
                    onAction: study.isEmpty ? _openAdd : null,
                  )
                : ListView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 96),
                    itemCount: records.length,
                    itemBuilder: (context, index) {
                      final record = records[index];
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: StudyCard(
                          record: record,
                          onTap: () => _openEdit(record),
                          onEdit: () => _openEdit(record),
                          onDuplicate: () => _duplicate(record),
                          onDelete: () => _confirmDelete(record),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
