import 'dart:convert';

import 'package:hive/hive.dart';

import '../../core/storage/local_db.dart';
import 'study_record.dart';

class StudyRepository {
  Box<String> get _box => LocalDb.studyBox;

  /// All saved records, newest first. Broken records are skipped.
  List<StudyRecord> getAll() {
    final list = <StudyRecord>[];
    for (final raw in _box.values) {
      try {
        final decoded = jsonDecode(raw);
        if (decoded is Map<String, dynamic>) {
          list.add(StudyRecord.fromJson(decoded));
        }
      } catch (_) {
        // skip a corrupted record instead of crashing
      }
    }
    list.sort((a, b) {
      final byDate = b.date.compareTo(a.date);
      return byDate != 0 ? byDate : b.createdAt.compareTo(a.createdAt);
    });
    return list;
  }

  Future<void> put(StudyRecord record) =>
      _box.put(record.id, jsonEncode(record.toJson()));

  Future<void> putAll(Iterable<StudyRecord> records) => _box.putAll({
        for (final r in records) r.id: jsonEncode(r.toJson()),
      });

  Future<void> delete(String id) => _box.delete(id);

  Future<void> clear() => _box.clear();
}
