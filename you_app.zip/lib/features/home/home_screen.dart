import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/localization/app_strings.dart';
import '../../core/utils/date_utils.dart';
import '../../core/utils/duration_utils.dart';
import '../../core/widgets/common_widgets.dart';
import '../goals/goal_provider.dart';
import '../goals/monthly_goal_card.dart';
import '../profile/settings_provider.dart';
import '../study/add_study_screen.dart';
import '../study/study_card.dart';
import '../study/study_provider.dart';
import '../study/study_record.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key, required this.onSeeAll});

  /// Switches to the Study tab.
  final VoidCallback onSeeAll;

  void _openAdd(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => const AddStudyScreen()),
    );
  }

  void _openEdit(BuildContext context, StudyRecord record) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => AddStudyScreen(existing: record),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final study = context.watch<StudyProvider>();
    final goal = context.watch<GoalProvider>();
    final settings = context.watch<SettingsProvider>();

    final now = DateTime.now();
    final greetKey = now.hour < 12
        ? 'greetMorning'
        : now.hour < 17
            ? 'greetAfternoon'
            : 'greetEvening';
    final name = settings.settings.userName.isEmpty
        ? context.tr('defaultName')
        : settings.settings.userName;
    final recent = study.allRecords.take(5).toList();

    final target = settings.settings.dailyTargetMinutes;
    final dailyProgress = target <= 0
        ? 0.0
        : (study.todayMinutes / target).clamp(0.0, 1.0).toDouble();

    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openAdd(context),
        icon: const Icon(Icons.add),
        label: Text(context.tr('addStudy')),
      ),
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: () async {
            await context.read<StudyProvider>().load();
            if (context.mounted) await context.read<GoalProvider>().load();
          },
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 96),
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    'YOU',
                    style: theme.textTheme.headlineMedium?.copyWith(
                      fontWeight: FontWeight.w800,
                      letterSpacing: 2,
                      color: scheme.primary,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      context.tr('tagline'),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: theme.textTheme.bodySmall
                          ?.copyWith(color: scheme.onSurfaceVariant),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Text(
                context.tr(greetKey, {'name': name}),
                style: theme.textTheme.titleLarge
                    ?.copyWith(fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 2),
              Text(
                AppDateUtils.formatFull(now, settings.languageCode),
                style: theme.textTheme.bodyMedium
                    ?.copyWith(color: scheme.onSurfaceVariant),
              ),
              const SizedBox(height: 16),
              if (study.errorKey != null) ...[
                ErrorBanner(
                  message: context.tr(study.errorKey!),
                  onRetry: () => context.read<StudyProvider>().load(),
                ),
                const SizedBox(height: 12),
              ],
              IntrinsicHeight(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Expanded(
                      child: StatCard(
                        label: context.tr('todaysTime'),
                        value: AppDurationUtils.formatMinutes(
                            context, study.todayMinutes),
                        icon: Icons.schedule,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: StatCard(
                        label: context.tr('todaysSessions'),
                        value: '${study.todaySessions}',
                        icon: Icons.menu_book,
                        color: scheme.tertiary,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: StatCard(
                        label: context.tr('dayStreak'),
                        value: '${study.currentStreak}',
                        icon: Icons.local_fire_department,
                        color: Colors.orange,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              ProgressCard(
                icon: Icons.today_outlined,
                title: context.tr('dailyTarget'),
                trailing:
                    '${(dailyProgress * 100).toStringAsFixed(0)}%',
                progress: dailyProgress,
                caption:
                    '${AppDurationUtils.formatMinutes(context, study.todayMinutes)} / ${AppDurationUtils.formatMinutes(context, target)}',
              ),
              const SizedBox(height: 12),
              MonthlyGoalCard(
                monthMinutes: study.monthMinutes,
                goalHours: goal.targetHours,
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: Text(
                      context.tr('recentStudies'),
                      style: theme.textTheme.titleMedium
                          ?.copyWith(fontWeight: FontWeight.w600),
                    ),
                  ),
                  if (study.allRecords.isNotEmpty)
                    TextButton(
                      onPressed: onSeeAll,
                      child: Text(context.tr('seeAll')),
                    ),
                ],
              ),
              const SizedBox(height: 8),
              if (recent.isEmpty)
                AppCard(
                  padding: const EdgeInsets.all(24),
                  child: SizedBox(
                    width: double.infinity,
                    child: Column(
                      children: [
                        Icon(Icons.auto_stories_outlined,
                            size: 40, color: scheme.onSurfaceVariant),
                        const SizedBox(height: 12),
                        Text(
                          context.tr('noRecordsYet'),
                          textAlign: TextAlign.center,
                          style: theme.textTheme.titleSmall
                              ?.copyWith(fontWeight: FontWeight.w600),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          context.tr('addFirstStudy'),
                          textAlign: TextAlign.center,
                          style: theme.textTheme.bodySmall
                              ?.copyWith(color: scheme.onSurfaceVariant),
                        ),
                        const SizedBox(height: 16),
                        FilledButton.icon(
                          onPressed: () => _openAdd(context),
                          icon: const Icon(Icons.add),
                          label: Text(context.tr('addStudy')),
                        ),
                      ],
                    ),
                  ),
                )
              else
                for (final r in recent)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: StudyCard(
                      record: r,
                      onTap: () => _openEdit(context, r),
                    ),
                  ),
            ],
          ),
        ),
      ),
    );
  }
}
