import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../core/constants/app_constants.dart';
import '../../core/localization/app_strings.dart';
import '../../core/storage/local_db.dart';
import '../../core/widgets/common_widgets.dart';
import '../backup/backup_service.dart';
import '../backup/import_screen.dart';
import '../goals/goal_provider.dart';
import '../goals/goals_screen.dart';
import '../revision/revision_provider.dart';
import '../study/study_provider.dart';
import 'settings_provider.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  Future<void> _editName(BuildContext context) async {
    final settings = context.read<SettingsProvider>();
    final controller =
        TextEditingController(text: settings.settings.userName);
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(ctx.tr('editName')),
        content: TextField(
          controller: controller,
          autofocus: true,
          textCapitalization: TextCapitalization.words,
          decoration: InputDecoration(labelText: ctx.tr('name')),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: Text(ctx.tr('cancel')),
          ),
          FilledButton(
            onPressed: () => Navigator.of(ctx).pop(controller.text),
            child: Text(ctx.tr('save')),
          ),
        ],
      ),
    );
    controller.dispose();
    if (result != null) await settings.setUserName(result);
  }

  Future<void> _export(BuildContext context) async {
    final study = context.read<StudyProvider>();
    final goals = context.read<GoalProvider>();
    final settings = context.read<SettingsProvider>();
    final revision = context.read<RevisionProvider>();
    final messenger = ScaffoldMessenger.of(context);
    final errorMsg = context.tr('genericError');
    final copiedMsg = context.tr('exportCopied', {
      'n': '${study.allRecords.length}',
    });
    try {
      final text = BackupService.export(
        records: study.allRecords,
        goals: goals.allGoals,
        settings: settings.settings,
        revisions: revision.revisedMap,
      );
      await Clipboard.setData(ClipboardData(text: text));
      messenger.showSnackBar(SnackBar(
        content: Text(copiedMsg),
        duration: const Duration(seconds: 6),
      ));
    } catch (_) {
      messenger.showSnackBar(SnackBar(content: Text(errorMsg)));
    }
  }

  Future<void> _resetAll(BuildContext context) async {
    final study = context.read<StudyProvider>();
    final goals = context.read<GoalProvider>();
    final settings = context.read<SettingsProvider>();
    final revision = context.read<RevisionProvider>();
    final messenger = ScaffoldMessenger.of(context);
    final clearedMsg = context.tr('dataCleared');
    final errorMsg = context.tr('genericError');

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(ctx.tr('clearConfirmTitle')),
        content: Text(ctx.tr('clearConfirmMessage')),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: Text(ctx.tr('cancel')),
          ),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: Theme.of(ctx).colorScheme.error,
              foregroundColor: Theme.of(ctx).colorScheme.onError,
            ),
            onPressed: () => Navigator.of(ctx).pop(true),
            child: Text(ctx.tr('delete')),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    try {
      await LocalDb.clearAll();
      await study.load();
      await goals.load();
      await settings.load();
      await revision.load();
      messenger.showSnackBar(SnackBar(content: Text(clearedMsg)));
    } catch (_) {
      messenger.showSnackBar(SnackBar(content: Text(errorMsg)));
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final provider = context.watch<SettingsProvider>();
    final goal = context.watch<GoalProvider>();
    final s = provider.settings;

    return Scaffold(
      appBar: AppBar(title: Text(context.tr('profileTitle'))),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 32),
        children: [
          AppCard(
            onTap: () => _editName(context),
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: scheme.primaryContainer,
                child: Icon(Icons.person, color: scheme.onPrimaryContainer),
              ),
              title: Text(
                s.userName.isEmpty ? context.tr('defaultName') : s.userName,
                style: theme.textTheme.titleMedium
                    ?.copyWith(fontWeight: FontWeight.w700),
              ),
              subtitle: Text(context.tr('name')),
              trailing: const Icon(Icons.edit_outlined),
            ),
          ),

          SectionHeader(context.tr('targetExam')),
          Wrap(
            spacing: 8,
            runSpacing: 4,
            children: [
              for (var i = 0; i < 5; i++)
                ChoiceChip(
                  label: Text(context.tr('exam_$i')),
                  selected: s.targetExam == i,
                  onSelected: (_) => provider.setTargetExam(i),
                ),
            ],
          ),

          SectionHeader(context.tr('dailyStudyTarget')),
          Wrap(
            spacing: 8,
            runSpacing: 4,
            children: [
              for (final m in AppConstants.dailyTargetOptions)
                ChoiceChip(
                  label: Text(
                    m < 60
                        ? '$m${context.tr('unitM')}'
                        : '${m ~/ 60}${context.tr('unitH')}'
                            '${m % 60 == 0 ? '' : ' ${m % 60}${context.tr('unitM')}'}',
                  ),
                  selected: s.dailyTargetMinutes == m,
                  onSelected: (_) => provider.setDailyTarget(m),
                ),
            ],
          ),

          SectionHeader(context.tr('monthlyGoal')),
          AppCard(
            onTap: () => showSetGoalDialog(context, goal.targetHours),
            child: ListTile(
              leading: const Icon(Icons.flag_outlined),
              title: Text(context.tr('setMonthlyGoal')),
              subtitle: Text(
                goal.targetHours > 0
                    ? '${goal.targetHours}${context.tr('unitH')}'
                    : context.tr('goalNotSet'),
              ),
              trailing: const Icon(Icons.chevron_right),
            ),
          ),

          SectionHeader(context.tr('language')),
          Wrap(
            spacing: 8,
            children: [
              ChoiceChip(
                label: const Text('বাংলা'),
                selected: s.languageCode == 'bn',
                onSelected: (_) => provider.setLanguage('bn'),
              ),
              ChoiceChip(
                label: const Text('English'),
                selected: s.languageCode == 'en',
                onSelected: (_) => provider.setLanguage('en'),
              ),
            ],
          ),

          SectionHeader(context.tr('theme')),
          Wrap(
            spacing: 8,
            children: [
              ChoiceChip(
                label: Text(context.tr('themeSystem')),
                selected: s.themeMode == 'system',
                onSelected: (_) => provider.setThemeMode('system'),
              ),
              ChoiceChip(
                label: Text(context.tr('themeLight')),
                selected: s.themeMode == 'light',
                onSelected: (_) => provider.setThemeMode('light'),
              ),
              ChoiceChip(
                label: Text(context.tr('themeDark')),
                selected: s.themeMode == 'dark',
                onSelected: (_) => provider.setThemeMode('dark'),
              ),
            ],
          ),

          SectionHeader(context.tr('notifications')),
          AppCard(
            child: SwitchListTile(
              title: Text(context.tr('notifications')),
              subtitle: Text(context.tr('notificationsHint')),
              value: false,
              onChanged: null,
            ),
          ),

          SectionHeader(context.tr('backup')),
          AppCard(
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.upload_outlined),
                  title: Text(context.tr('exportData')),
                  subtitle: Text(context.tr('exportHint')),
                  onTap: () => _export(context),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.download_outlined),
                  title: Text(context.tr('importData')),
                  subtitle: Text(context.tr('importHint')),
                  onTap: () {
                    Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) => const ImportScreen(),
                      ),
                    );
                  },
                ),
              ],
            ),
          ),

          SectionHeader(context.tr('dataSection')),
          AppCard(
            child: ListTile(
              leading: Icon(Icons.delete_forever, color: scheme.error),
              title: Text(
                context.tr('clearAllData'),
                style: TextStyle(color: scheme.error),
              ),
              onTap: () => _resetAll(context),
            ),
          ),

          SectionHeader(context.tr('about')),
          AppCard(
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.info_outline),
                  title: Text(
                    AppConstants.appName,
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                  subtitle: Text(context.tr('tagline')),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.numbers),
                  title: Text(context.tr('version')),
                  trailing: const Text(AppConstants.appVersion),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Text(
            context.tr('offlineNote'),
            textAlign: TextAlign.center,
            style: theme.textTheme.bodySmall
                ?.copyWith(color: scheme.onSurfaceVariant),
          ),
        ],
      ),
    );
  }
}
