import 'dart:convert';

import 'package:flutter/material.dart';

import '../../core/storage/local_db.dart';
import 'app_settings.dart';

class SettingsProvider extends ChangeNotifier {
  static const String _key = 'settings';

  AppSettings _settings = const AppSettings();

  AppSettings get settings => _settings;
  String get languageCode => _settings.languageCode;
  Locale get locale => Locale(_settings.languageCode);

  ThemeMode get themeMode {
    switch (_settings.themeMode) {
      case 'light':
        return ThemeMode.light;
      case 'dark':
        return ThemeMode.dark;
      default:
        return ThemeMode.system;
    }
  }

  /// Subjects shown in the study form: built-in ones + the user's own.
  List<String> get customSubjects => _settings.customSubjects;

  Future<void> load() async {
    try {
      final raw = LocalDb.settingsBox.get(_key);
      if (raw == null) {
        _settings = const AppSettings();
      } else {
        final decoded = jsonDecode(raw);
        _settings = decoded is Map<String, dynamic>
            ? AppSettings.fromJson(decoded)
            : const AppSettings();
      }
    } catch (_) {
      _settings = const AppSettings();
    }
    notifyListeners();
  }

  Future<void> _update(AppSettings next) async {
    _settings = next;
    notifyListeners(); // update the UI first, then save
    try {
      await LocalDb.settingsBox.put(_key, jsonEncode(next.toJson()));
    } catch (_) {
      // saving failed; the app keeps working with the in-memory value
    }
  }

  Future<void> setLanguage(String code) async {
    if (code != 'bn' && code != 'en') return;
    await _update(_settings.copyWith(languageCode: code));
  }

  Future<void> setThemeMode(String mode) async {
    if (mode != 'system' && mode != 'light' && mode != 'dark') return;
    await _update(_settings.copyWith(themeMode: mode));
  }

  Future<void> setUserName(String name) =>
      _update(_settings.copyWith(userName: name.trim()));

  Future<void> setTargetExam(int index) =>
      _update(_settings.copyWith(targetExam: index));

  Future<void> setDailyTarget(int minutes) =>
      _update(_settings.copyWith(dailyTargetMinutes: minutes));

  Future<void> addCustomSubject(String name) async {
    final s = name.trim();
    if (s.isEmpty || _settings.customSubjects.contains(s)) return;
    await _update(
      _settings.copyWith(customSubjects: [..._settings.customSubjects, s]),
    );
  }

  /// Restores name, target exam, daily target and custom subjects from a
  /// backup. Language and theme stay as the user has them now.
  Future<void> importProfile(AppSettings imported) async {
    final merged = <String>{
      ..._settings.customSubjects,
      ...imported.customSubjects,
    }.toList();
    await _update(_settings.copyWith(
      userName: imported.userName,
      targetExam: imported.targetExam,
      dailyTargetMinutes: imported.dailyTargetMinutes,
      customSubjects: merged,
    ));
  }
}
