class AppSettings {
  const AppSettings({
    this.languageCode = 'bn',
    this.themeMode = 'system',
    this.userName = '',
    this.targetExam = 0,
    this.dailyTargetMinutes = 60,
    this.customSubjects = const <String>[],
  });

  final String languageCode; // 'bn' (default) or 'en'
  final String themeMode; // 'system' | 'light' | 'dark'
  final String userName;
  final int targetExam; // 0 BCS, 1 Primary Teacher, 2 Bank/Govt, 3 Other, 4 Custom
  final int dailyTargetMinutes;
  final List<String> customSubjects;

  AppSettings copyWith({
    String? languageCode,
    String? themeMode,
    String? userName,
    int? targetExam,
    int? dailyTargetMinutes,
    List<String>? customSubjects,
  }) {
    return AppSettings(
      languageCode: languageCode ?? this.languageCode,
      themeMode: themeMode ?? this.themeMode,
      userName: userName ?? this.userName,
      targetExam: targetExam ?? this.targetExam,
      dailyTargetMinutes: dailyTargetMinutes ?? this.dailyTargetMinutes,
      customSubjects: customSubjects ?? this.customSubjects,
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'languageCode': languageCode,
        'themeMode': themeMode,
        'userName': userName,
        'targetExam': targetExam,
        'dailyTargetMinutes': dailyTargetMinutes,
        'customSubjects': customSubjects,
      };

  factory AppSettings.fromJson(Map<String, dynamic> json) {
    final lang = json['languageCode'];
    final theme = json['themeMode'];
    final exam = (json['targetExam'] as num?)?.toInt() ?? 0;
    final daily = (json['dailyTargetMinutes'] as num?)?.toInt() ?? 60;
    final custom = json['customSubjects'];
    return AppSettings(
      languageCode: lang == 'en' ? 'en' : 'bn',
      themeMode: (theme == 'light' || theme == 'dark') ? theme as String : 'system',
      userName: (json['userName'] as String?) ?? '',
      targetExam: (exam < 0 || exam > 4) ? 0 : exam,
      dailyTargetMinutes: daily <= 0 ? 60 : daily,
      customSubjects: custom is List
          ? custom.whereType<String>().toList()
          : const <String>[],
    );
  }
}
