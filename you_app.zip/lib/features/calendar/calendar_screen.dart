import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/constants/app_constants.dart';
import '../../core/constants/subjects.dart';
import '../../core/localization/app_strings.dart';
import '../../core/utils/date_utils.dart';
import '../../core/utils/duration_utils.dart';
import '../../core/widgets/common_widgets.dart';
import '../profile/settings_provider.dart';
import '../study/add_study_screen.dart';
import '../study/study_card.dart';
import '../study/study_provider.dart';
import '../study/study_record.dart';

class CalendarScreen extends StatefulWidget {
  const CalendarScreen({super.key});

  @override
  State<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends State<CalendarScreen> {
  late DateTime _focusedMonth;
  late DateTime _selectedDay;

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    _focusedMonth = DateTime(now.year, now.month, 1);
    _selectedDay = DateTime(now.year, now.month, now.day);
  }

  void _changeMonth(int delta) {
    setState(() {
      _focusedMonth =
          DateTime(_focusedMonth.year, _focusedMonth.month + delta, 1);
    });
  }

  void _goToday() {
    final now = DateTime.now();
    setState(() {
      _focusedMonth = DateTime(now.year, now.month, 1);
      _selectedDay = DateTime(now.year, now.month, now.day);
    });
  }

  void _openEdit(StudyRecord record) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => AddStudyScreen(existing: record),
      ),
    );
  }

  void _openAddForDay() {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => AddStudyScreen(initialDate: _selectedDay),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final study = context.watch<StudyProvider>();
    final locale = context.watch<SettingsProvider>().languageCode;

    final daysInMonth =
        AppDateUtils.daysInMonth(_focusedMonth.year, _focusedMonth.month);
    final blanks = AppDateUtils.leadingBlanks(_focusedMonth);
    final rows = ((blanks + daysInMonth) / 7).ceil();

    final selectedRecords = study.recordsForDay(_selectedDay);
    final selectedMinutes =
        selectedRecords.fold<int>(0, (s, r) => s + r.durationMinutes);
    final selectedSubjects = <String>{
      for (final r in selectedRecords) r.subject,
    }.toList();
    final selectedTopics = <String>{
      for (final r in selectedRecords) r.topic,
    }.length;
    final today = DateTime.now();

    return Scaffold(
      appBar: AppBar(
        title: Text(context.tr('calendar')),
        actions: [
          IconButton(
            onPressed: _goToday,
            icon: const Icon(Icons.today_outlined),
            tooltip: context.tr('filterToday'),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(12, 4, 12, 32),
        children: [
          Row(
            children: [
              IconButton(
                onPressed: () => _changeMonth(-1),
                icon: const Icon(Icons.chevron_left),
              ),
              Expanded(
                child: Center(
                  child: Text(
                    AppDateUtils.formatMonthYear(_focusedMonth, locale),
                    style: theme.textTheme.titleMedium
                        ?.copyWith(fontWeight: FontWeight.w600),
                  ),
                ),
              ),
              IconButton(
                onPressed: () => _changeMonth(1),
                icon: const Icon(Icons.chevron_right),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Row(
            children: [
              for (var i = 0; i < 7; i++)
                Expanded(
                  child: Center(
                    child: Text(
                      AppDateUtils.weekdayShort(i, locale),
                      style: theme.textTheme.labelSmall?.copyWith(
                        color: scheme.onSurfaceVariant,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 4),
          for (var row = 0; row < rows; row++)
            Row(
              children: [
                for (var col = 0; col < 7; col++)
                  _buildCell(
                    context,
                    study,
                    dayNumber: row * 7 + col - blanks + 1,
                    daysInMonth: daysInMonth,
                    today: today,
                  ),
              ],
            ),
          const SizedBox(height: 12),
          Wrap(
            alignment: WrapAlignment.center,
            spacing: 16,
            runSpacing: 4,
            children: [
              _Legend(
                color: scheme.primaryContainer,
                label: context.tr('legendStudied'),
              ),
              _Legend(
                color: scheme.primary,
                label: context.tr('legendHeavy'),
              ),
              _Legend(
                color: scheme.surfaceContainerHighest,
                label: context.tr('legendNone'),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Text(
            AppDateUtils.formatFull(_selectedDay, locale),
            style: theme.textTheme.titleMedium
                ?.copyWith(fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 8),
          if (selectedRecords.isEmpty)
            Text(
              context.tr('noStudyOnDay'),
              style: theme.textTheme.bodyMedium
                  ?.copyWith(color: scheme.onSurfaceVariant),
            )
          else ...[
            AppCard(
              padding: const EdgeInsets.all(14),
              child: SizedBox(
                width: double.infinity,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${context.tr('totalTime')}: '
                      '${AppDurationUtils.formatMinutes(context, selectedMinutes)}'
                      '  ·  ${selectedRecords.length} ${context.tr('sessions')}'
                      '  ·  $selectedTopics ${context.tr('topicsStudied')}',
                      style: theme.textTheme.bodyMedium
                          ?.copyWith(fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 6,
                      runSpacing: 4,
                      children: [
                        for (final s in selectedSubjects)
                          Chip(
                            visualDensity: VisualDensity.compact,
                            label: Text(
                              '${Subjects.icon(s)} ${Subjects.label(context, s)}',
                            ),
                          ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),
            for (final r in selectedRecords)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: StudyCard(record: r, onTap: () => _openEdit(r)),
              ),
          ],
          const SizedBox(height: 8),
          FilledButton.tonalIcon(
            onPressed: _openAddForDay,
            icon: const Icon(Icons.add),
            label: Text(context.tr('addForDay')),
          ),
        ],
      ),
    );
  }

  Widget _buildCell(
    BuildContext context,
    StudyProvider study, {
    required int dayNumber,
    required int daysInMonth,
    required DateTime today,
  }) {
    if (dayNumber < 1 || dayNumber > daysInMonth) {
      return const Expanded(child: SizedBox(height: 46));
    }
    final scheme = Theme.of(context).colorScheme;
    final date =
        DateTime(_focusedMonth.year, _focusedMonth.month, dayNumber);
    final minutes = study.minutesOn(date);
    final hasStudy = minutes > 0;
    final heavy = minutes >= AppConstants.heavyStudyMinutes;
    final selected = AppDateUtils.isSameDay(date, _selectedDay);
    final isToday = AppDateUtils.isSameDay(date, today);

    final Color? bg = heavy
        ? scheme.primary
        : hasStudy
            ? scheme.primaryContainer
            : null;
    final Color fg = heavy
        ? scheme.onPrimary
        : hasStudy
            ? scheme.onPrimaryContainer
            : scheme.onSurface;

    return Expanded(
      child: InkWell(
        onTap: () => setState(() => _selectedDay = date),
        borderRadius: BorderRadius.circular(10),
        child: Container(
          height: 46,
          margin: const EdgeInsets.all(2),
          decoration: BoxDecoration(
            color: bg,
            borderRadius: BorderRadius.circular(10),
            border: selected
                ? Border.all(color: scheme.tertiary, width: 2.5)
                : isToday
                    ? Border.all(color: scheme.primary, width: 1.5)
                    : null,
          ),
          alignment: Alignment.center,
          child: Text(
            '$dayNumber',
            style: TextStyle(
              fontSize: 14,
              fontWeight:
                  (selected || isToday) ? FontWeight.w800 : FontWeight.w500,
              color: fg,
            ),
          ),
        ),
      ),
    );
  }
}

class _Legend extends StatelessWidget {
  const _Legend({required this.color, required this.label});

  final Color color;
  final String label;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 14,
          height: 14,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(4),
          ),
        ),
        const SizedBox(width: 6),
        Text(
          label,
          style: theme.textTheme.labelSmall
              ?.copyWith(color: theme.colorScheme.onSurfaceVariant),
        ),
      ],
    );
  }
}
