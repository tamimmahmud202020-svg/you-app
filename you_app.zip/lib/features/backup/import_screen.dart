import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../core/localization/app_strings.dart';
import '../../core/widgets/common_widgets.dart';
import '../goals/goal_provider.dart';
import '../profile/settings_provider.dart';
import '../revision/revision_provider.dart';
import '../study/study_provider.dart';
import 'backup_service.dart';

class ImportScreen extends StatefulWidget {
  const ImportScreen({super.key});

  @override
  State<ImportScreen> createState() => _ImportScreenState();
}

class _ImportScreenState extends State<ImportScreen> {
  final TextEditingController _controller = TextEditingController();
  String? _error;
  bool _busy = false;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _paste() async {
    try {
      final data = await Clipboard.getData(Clipboard.kTextPlain);
      final text = data?.text;
      if (text != null && mounted) {
        setState(() {
          _controller.text = text;
          _error = null;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _error = context.tr('genericError'));
    }
  }

  Future<void> _import() async {
    final study = context.read<StudyProvider>();
    final goals = context.read<GoalProvider>();
    final settings = context.read<SettingsProvider>();
    final revision = context.read<RevisionProvider>();
    final navigator = Navigator.of(context);
    final messenger = ScaffoldMessenger.of(context);
    final invalidMsg = context.tr('importInvalid');
    final emptyMsg = context.tr('importEmpty');
    final errorMsg = context.tr('genericError');

    final BackupData data;
    try {
      data = BackupService.parse(_controller.text);
    } on FormatException {
      setState(() => _error = invalidMsg);
      return;
    }
    if (data.records.isEmpty && data.goals.isEmpty && data.revisions.isEmpty) {
      setState(() => _error = emptyMsg);
      return;
    }

    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final count = await study.importRecords(data.records);
      if (data.goals.isNotEmpty) await goals.importGoals(data.goals);
      if (data.profile != null) await settings.importProfile(data.profile!);
      if (data.revisions.isNotEmpty) {
        await revision.importRevisions(data.revisions);
      }
      if (!mounted) return;
      messenger.showSnackBar(SnackBar(
        content: Text(context.tr('importSuccess', {'n': '$count'})),
      ));
      navigator.pop();
    } catch (_) {
      if (mounted) {
        setState(() {
          _busy = false;
          _error = errorMsg;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;

    return Scaffold(
      appBar: AppBar(title: Text(context.tr('importTitle'))),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                context.tr('importInfo'),
                style: theme.textTheme.bodySmall
                    ?.copyWith(color: scheme.onSurfaceVariant),
              ),
              const SizedBox(height: 12),
              Expanded(
                child: TextField(
                  controller: _controller,
                  maxLines: null,
                  expands: true,
                  textAlignVertical: TextAlignVertical.top,
                  keyboardType: TextInputType.multiline,
                  onChanged: (_) {
                    if (_error != null) setState(() => _error = null);
                  },
                  decoration: InputDecoration(
                    hintText: context.tr('importPasteHint'),
                  ),
                ),
              ),
              if (_error != null) ...[
                const SizedBox(height: 12),
                ErrorBanner(message: _error!),
              ],
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _busy ? null : _paste,
                      icon: const Icon(Icons.content_paste),
                      label: Text(
                        context.tr('pasteFromClipboard'),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: _busy ? null : _import,
                      icon: _busy
                          ? const SizedBox(
                              width: 16,
                              height: 16,
                              child:
                                  CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Icon(Icons.download_done),
                      label: Text(context.tr('importButton')),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
