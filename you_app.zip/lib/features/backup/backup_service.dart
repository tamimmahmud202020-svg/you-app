import 'dart:convert';

import '../goals/monthly_goal.dart';
import '../profile/app_settings.dart';
import '../study/study_record.dart';

class BackupData {
  const BackupData({
    required this.records,
    required this.goals,
    required this.profile,
    required this.skipped,
  });

  final List<StudyRecord> records;
  final List<MonthlyGoal> goals;
  final AppSettings? profile;
  final int skipped; // broken items that were ignored
}

/// Export / import of all user data as one JSON text.
class BackupService {
  BackupService._();

  static const String appId = 'YOU';
  static const int formatVersion = 1;

  static String export({
    required List<StudyRecord> records,
    required List<MonthlyGoal> goals,
    required AppSettings settings,
  }) {
    final map = <String, dynamic>{
      'app': appId,
      'formatVersion': formatVersion,
      'exportedAt': DateTime.now().toIso8601String(),
      'profile': settings.toJson(),
      'goals': goals.map((g) => g.toJson()).toList(),
      'records': records.map((r) => r.toJson()).toList(),
    };
    return const JsonEncoder.withIndent('  ').convert(map);
  }

  /// Throws [FormatException] if the text is not a valid YOU backup.
  static BackupData parse(String raw) {
    final text = raw.trim();
    if (text.isEmpty) throw const FormatException('Empty backup');

    final dynamic decoded = jsonDecode(text);
    if (decoded is! Map<String, dynamic> || decoded['app'] != appId) {
      throw const FormatException('Not a YOU backup');
    }

    var skipped = 0;

    final records = <StudyRecord>[];
    final rawRecords = decoded['records'];
    if (rawRecords is List) {
      for (final item in rawRecords) {
        try {
          if (item is Map<String, dynamic>) {
            records.add(StudyRecord.fromJson(item));
          } else {
            skipped++;
          }
        } catch (_) {
          skipped++;
        }
      }
    }

    final goals = <MonthlyGoal>[];
    final rawGoals = decoded['goals'];
    if (rawGoals is List) {
      for (final item in rawGoals) {
        try {
          if (item is Map<String, dynamic>) {
            goals.add(MonthlyGoal.fromJson(item));
          } else {
            skipped++;
          }
        } catch (_) {
          skipped++;
        }
      }
    }

    AppSettings? profile;
    final rawProfile = decoded['profile'];
    if (rawProfile is Map<String, dynamic>) {
      try {
        profile = AppSettings.fromJson(rawProfile);
      } catch (_) {
        profile = null;
      }
    }

    return BackupData(
      records: records,
      goals: goals,
      profile: profile,
      skipped: skipped,
    );
  }
}
