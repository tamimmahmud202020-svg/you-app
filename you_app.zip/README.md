# YOU - BCS & Bangladesh Govt Job Preparation (Phase A)

Study. Remember. Improve.

Offline-first Flutter app. Study data is stored on the device (Hive).
Phase A: Home, Study entry/history, Calendar, Goals, Profile, Backup (copy/paste JSON), Bangla + English.
